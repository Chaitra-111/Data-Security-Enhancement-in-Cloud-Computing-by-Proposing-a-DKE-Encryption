package com.edke.cloudsecurity;

import com.edke.service.DecryptionService;
import com.edke.service.EncryptionService;
import com.edke.service.HashService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")
class DecryptionServiceTest {

    @Autowired
    private DecryptionService decryptionService;

    @Autowired
    private EncryptionService encryptionService;

    @Autowired
    private HashService hashService;

    @BeforeEach
    void setUp() {
        // Services are autowired by Spring
    }

    @Test
    void testDecryptFile() throws Exception {
        byte[] originalData = "Hello, Encryption!".getBytes();
        Map<String, Object> encryptionResult = encryptionService.encryptFile(originalData);

        byte[] encryptedData = (byte[]) encryptionResult.get("encryptedData");
        byte[] encryptedAESKey = (byte[]) encryptionResult.get("encryptedAESKey");
        byte[] vmKey = (byte[]) encryptionResult.get("vmKey");
        byte[] serverKey = (byte[]) encryptionResult.get("serverKey");
        String originalHash = (String) encryptionResult.get("originalHash");

        Map<String, Object> decryptionResult = decryptionService.decryptFile(
                encryptedData, encryptedAESKey, vmKey, serverKey, originalHash
        );

        assertNotNull(decryptionResult);
        byte[] decryptedData = (byte[]) decryptionResult.get("decryptedData");
        assertArrayEquals(originalData, decryptedData);
        assertTrue((boolean) decryptionResult.get("integrityVerified"));
    }

    @Test
    void testDecryptLargeFile() throws Exception {
        byte[] largeData = new byte[1024 * 1024]; // 1MB
        for (int i = 0; i < largeData.length; i++) {
            largeData[i] = (byte) (i % 256);
        }

        Map<String, Object> encryptionResult = encryptionService.encryptFile(largeData);
        byte[] encryptedData = (byte[]) encryptionResult.get("encryptedData");
        byte[] encryptedAESKey = (byte[]) encryptionResult.get("encryptedAESKey");
        byte[] vmKey = (byte[]) encryptionResult.get("vmKey");
        byte[] serverKey = (byte[]) encryptionResult.get("serverKey");
        String originalHash = (String) encryptionResult.get("originalHash");

        long startTime = System.currentTimeMillis();
        Map<String, Object> decryptionResult = decryptionService.decryptFile(
                encryptedData, encryptedAESKey, vmKey, serverKey, originalHash
        );
        long decryptionTime = System.currentTimeMillis() - startTime;

        byte[] decryptedData = (byte[]) decryptionResult.get("decryptedData");
        assertArrayEquals(largeData, decryptedData);
        assertTrue(decryptionTime < 5000, "Decryption should complete in less than 5 seconds");
    }

    @Test
    void testIntegrityVerificationFails() throws Exception {
        byte[] originalData = "Test Data".getBytes();
        Map<String, Object> encryptionResult = encryptionService.encryptFile(originalData);

        byte[] encryptedData = (byte[]) encryptionResult.get("encryptedData");
        byte[] encryptedAESKey = (byte[]) encryptionResult.get("encryptedAESKey");
        byte[] vmKey = (byte[]) encryptionResult.get("vmKey");
        byte[] serverKey = (byte[]) encryptionResult.get("serverKey");
        String corruptedHash = "invalid_hash_value";

        Map<String, Object> decryptionResult = decryptionService.decryptFile(
                encryptedData, encryptedAESKey, vmKey, serverKey, corruptedHash
        );

        assertFalse((boolean) decryptionResult.get("integrityVerified"));
    }

    @Test
    void testDecryptServiceNotNull() {
        assertNotNull(decryptionService);
    }

    @Test
    void testVerifyIntegrity() throws Exception {
        byte[] data = "Verify Integrity Test".getBytes();
        String correctHash = hashService.generateHash(data);

        assertTrue(decryptionService.verifyIntegrity(data, correctHash));

        byte[] wrongData = "Wrong Data".getBytes();
        assertFalse(decryptionService.verifyIntegrity(wrongData, correctHash));
    }

    @Test
    void testRoundTripEncryptionDecryption() throws Exception {
        String originalMessage = "Complete Roundtrip Test";
        byte[] originalData = originalMessage.getBytes();

        Map<String, Object> encryptionResult = encryptionService.encryptFile(originalData);
        Map<String, Object> decryptionResult = decryptionService.decryptFile(
                (byte[]) encryptionResult.get("encryptedData"),
                (byte[]) encryptionResult.get("encryptedAESKey"),
                (byte[]) encryptionResult.get("vmKey"),
                (byte[]) encryptionResult.get("serverKey"),
                (String) encryptionResult.get("originalHash")
        );

        byte[] decryptedData = (byte[]) decryptionResult.get("decryptedData");
        assertEquals(originalMessage, new String(decryptedData));
        assertTrue((boolean) decryptionResult.get("integrityVerified"));
    }
}

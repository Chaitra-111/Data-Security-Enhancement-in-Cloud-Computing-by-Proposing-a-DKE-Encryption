package com.edke.cloudsecurity;

import com.edke.service.PerformanceAnalyzer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")
class PerformanceAnalyzerTest {

    private PerformanceAnalyzer performanceAnalyzer;

    @BeforeEach
    void setUp() {
        performanceAnalyzer = new PerformanceAnalyzer();
    }

    @Test
    void testAnalyzeEncryptionPerformance() {
        // Arrange
        long startTime = System.currentTimeMillis();
        long endTime = startTime + 50; // 50ms
        long fileSize = 1024 * 1024; // 1MB

        // Act
        Map<String, Object> metrics = performanceAnalyzer.analyzeEncryptionPerformance(
                startTime, endTime, fileSize
        );

        // Assert
        assertNotNull(metrics);
        assertEquals(50L, metrics.get("encryptionTimeMs"));
        assertEquals(fileSize, metrics.get("fileSizeBytes"));
        assertEquals(1.0, (Double) metrics.get("fileSizeMB"), 0.01);
        assertNotNull(metrics.get("throughputMBps"));
        assertEquals("AES-DKE", metrics.get("algorithm"));
    }

    @Test
    void testAnalyzeDecryptionPerformance() {
        // Arrange
        long startTime = System.currentTimeMillis();
        long endTime = startTime + 40; // 40ms
        long fileSize = 512 * 1024; // 512KB

        // Act
        Map<String, Object> metrics = performanceAnalyzer.analyzeDecryptionPerformance(
                startTime, endTime, fileSize
        );

        // Assert
        assertNotNull(metrics);
        assertEquals(40L, metrics.get("decryptionTimeMs"));
        assertEquals(fileSize, metrics.get("fileSizeBytes"));
        assertNotNull(metrics.get("throughputMBps"));
        assertEquals("AES-DKE", metrics.get("algorithm"));
    }

    @Test
    void testCompareWithOtherAlgorithms() {
        // Arrange
        long aesDkeTime = 50;
        long aesOnlyTime = 60;
        long rsaTime = 500;

        // Act
        Map<String, Object> comparison = performanceAnalyzer.compareWithOtherAlgorithms(
                aesDkeTime, aesOnlyTime, rsaTime
        );

        // Assert
        assertNotNull(comparison);
        assertEquals(aesDkeTime, comparison.get("aesDkeTimeMs"));
        assertEquals(aesOnlyTime, comparison.get("aesOnlyTimeMs"));
        assertEquals(rsaTime, comparison.get("rsaTimeMs"));
        assertEquals("AES-DKE", comparison.get("bestAlgorithm"));

        // AES is 20% slower than AES-DKE
        double aesVsAesDke = (Double) comparison.get("aesVsAesDkePercentage");
        assertTrue(aesVsAesDke > 0);
    }

    @Test
    void testCalculateQoS() {
        // Arrange
        long encryptionTime = 50;
        long decryptionTime = 40;
        long fileSize = 1024 * 1024; // 1MB
        Long userId = 1L;

        // Act
        Map<String, Object> qos = performanceAnalyzer.calculateQoS(
                encryptionTime, decryptionTime, fileSize, userId
        );

        // Assert
        assertNotNull(qos);
        assertEquals(0.09, (Double) qos.get("responseTimeSeconds"), 0.01);
        assertNotNull(qos.get("estimatedCostUSD"));
        assertEquals(99.9, qos.get("availabilityPercentage"));
        assertEquals(userId, qos.get("userId"));
    }

    @Test
    void testGeneratePerformanceReport() {
        // Arrange
        long encryptionTime = 50;
        long decryptionTime = 40;
        long fileSize = 2 * 1024 * 1024; // 2MB
        String filePath = "test_document.pdf";
        String algorithm = "AES-DKE";

        // Act
        Map<String, Object> report = performanceAnalyzer.generatePerformanceReport(
                encryptionTime, decryptionTime, fileSize, filePath, algorithm
        );

        // Assert
        assertNotNull(report);
        assertEquals(filePath, report.get("filePath"));
        assertEquals(2.0, (Double) report.get("fileSizeMB"), 0.01);
        assertEquals(encryptionTime, report.get("encryptionTimeMs"));
        assertEquals(decryptionTime, report.get("decryptionTimeMs"));
        assertEquals(encryptionTime + decryptionTime, report.get("totalTimeMs"));
        assertEquals(algorithm, report.get("algorithm"));
        assertNotNull(report.get("encryptionThroughputMBps"));
        assertNotNull(report.get("decryptionThroughputMBps"));
        assertNotNull(report.get("avgThroughputMBps"));
    }

    @Test
    void testThroughputCalculation() {
        // Arrange - 1MB in 50ms = 20 MB/s
        long startTime = System.currentTimeMillis();
        long endTime = startTime + 50;
        long fileSize = 1024 * 1024;

        // Act
        Map<String, Object> metrics = performanceAnalyzer.analyzeEncryptionPerformance(
                startTime, endTime, fileSize
        );

        // Assert
        double throughput = (Double) metrics.get("throughputMBps");
        assertEquals(20.0, throughput, 0.5); // Allow 0.5 MB/s variance
    }

    @Test
    void testPerformanceWithSmallFile() {
        // Arrange - 1KB file
        long startTime = System.currentTimeMillis();
        long endTime = startTime + 1;
        long fileSize = 1024;

        // Act
        Map<String, Object> metrics = performanceAnalyzer.analyzeEncryptionPerformance(
                startTime, endTime, fileSize
        );

        // Assert
        assertNotNull(metrics);
        assertEquals(1024L, metrics.get("fileSizeBytes"));
        assertEquals(0.001, (Double) metrics.get("fileSizeMB"), 0.0001);
    }

    @Test
    void testPerformanceWithLargeFile() {
        // Arrange - 100MB file with realistic timing
        long startTime = System.currentTimeMillis();
        long endTime = startTime + 500; // 500ms
        long fileSize = 100 * 1024 * 1024;

        // Act
        Map<String, Object> metrics = performanceAnalyzer.analyzeEncryptionPerformance(
                startTime, endTime, fileSize
        );

        // Assert
        assertNotNull(metrics);
        assertEquals(100.0, (Double) metrics.get("fileSizeMB"), 0.01);
        assertNotNull(metrics.get("throughputMBps"));
    }
}

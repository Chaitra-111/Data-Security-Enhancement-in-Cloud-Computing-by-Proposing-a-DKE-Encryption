package com.edke.cloudsecurity;

import com.edke.model.User;
import com.edke.repository.UserRepository;
import com.edke.service.UserService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")
@Transactional
class UserServiceTest {

    @Autowired
    private UserService userService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @BeforeEach
    void setUp() {
        // Clear database before each test
        userRepository.deleteAll();
    }

    @Test
    void testCreateUser() {
        // Arrange
        String username = "testuser";
        String password = "password123";
        String email = "test@example.com";
        User.Role role = User.Role.AUTHORIZED_USER;

        // Act
        User user = userService.createUser(username, password, email, role);

        // Assert
        assertNotNull(user);
        assertNotNull(user.getId());
        assertEquals(username, user.getUsername());
        assertEquals(email, user.getEmail());
        assertEquals(role, user.getRole());
        assertTrue(user.isEnabled());
        assertTrue(passwordEncoder.matches(password, user.getPassword()));
    }

    @Test
    void testCreateUserDuplicateUsername() {
        // Arrange
        userService.createUser("duplicate", "pass123", "first@example.com", User.Role.AUTHORIZED_USER);

        // Act & Assert
        assertThrows(RuntimeException.class, () -> {
            userService.createUser("duplicate", "pass456", "second@example.com", User.Role.AUTHORIZED_USER);
        });
    }

    @Test
    void testCreateUserDuplicateEmail() {
        // Arrange
        userService.createUser("user1", "pass123", "duplicate@example.com", User.Role.AUTHORIZED_USER);

        // Act & Assert
        assertThrows(RuntimeException.class, () -> {
            userService.createUser("user2", "pass456", "duplicate@example.com", User.Role.AUTHORIZED_USER);
        });
    }

    @Test
    void testFindByUsername() {
        // Arrange
        String username = "findme";
        User created = userService.createUser(username, "password", "find@example.com", User.Role.DATA_OWNER);

        // Act
        var found = userService.findByUsername(username);

        // Assert
        assertTrue(found.isPresent());
        assertEquals(created.getId(), found.get().getId());
        assertEquals(username, found.get().getUsername());
    }

    @Test
    void testFindByUsernameNotFound() {
        // Act
        var found = userService.findByUsername("nonexistent");

        // Assert
        assertTrue(found.isEmpty());
    }

    @Test
    void testFindById() {
        // Arrange
        User created = userService.createUser("findbyid", "pass123", "byid@example.com", User.Role.ADMIN);

        // Act
        var found = userService.findById(created.getId());

        // Assert
        assertTrue(found.isPresent());
        assertEquals(created.getId(), found.get().getId());
    }

    @Test
    void testGetAllUsers() {
        // Arrange
        userService.createUser("user1", "pass1", "user1@example.com", User.Role.AUTHORIZED_USER);
        userService.createUser("user2", "pass2", "user2@example.com", User.Role.DATA_OWNER);
        userService.createUser("user3", "pass3", "user3@example.com", User.Role.ADMIN);

        // Act
        var allUsers = userService.getAllUsers();

        // Assert
        assertEquals(3, allUsers.size());
    }

    @Test
    void testDeleteUser() {
        // Arrange
        User created = userService.createUser("todelete", "pass123", "delete@example.com", User.Role.AUTHORIZED_USER);
        long userId = created.getId();

        // Act
        userService.deleteUser(userId);

        // Assert
        var found = userService.findById(userId);
        assertTrue(found.isEmpty());
    }

    @Test
    void testUpdateUserRole() {
        // Arrange
        User created = userService.createUser("rolechange", "pass123", "role@example.com", User.Role.AUTHORIZED_USER);
        assertEquals(User.Role.AUTHORIZED_USER, created.getRole());

        // Act
        User updated = userService.updateUserRole(created.getId(), User.Role.DATA_OWNER);

        // Assert
        assertEquals(User.Role.DATA_OWNER, updated.getRole());
        var fetched = userService.findById(created.getId());
        assertEquals(User.Role.DATA_OWNER, fetched.get().getRole());
    }

    @Test
    void testUpdateUserRoleToAdmin() {
        // Arrange
        User created = userService.createUser("toadmin", "pass123", "toadmin@example.com", User.Role.AUTHORIZED_USER);

        // Act
        User updated = userService.updateUserRole(created.getId(), User.Role.ADMIN);

        // Assert
        assertEquals(User.Role.ADMIN, updated.getRole());
    }

    @Test
    void testUpdateUserRoleNotFound() {
        // Arrange
        long nonexistentId = 999L;

        // Act & Assert
        assertThrows(RuntimeException.class, () -> {
            userService.updateUserRole(nonexistentId, User.Role.ADMIN);
        });
    }

    @Test
    void testExistsByUsername() {
        // Arrange
        userService.createUser("existing", "pass123", "exist@example.com", User.Role.AUTHORIZED_USER);

        // Act & Assert
        assertTrue(userService.existsByUsername("existing"));
        assertFalse(userService.existsByUsername("nonexisting"));
    }

    @Test
    void testExistsByEmail() {
        // Arrange
        userService.createUser("user", "pass123", "existing@example.com", User.Role.AUTHORIZED_USER);

        // Act & Assert
        assertTrue(userService.existsByEmail("existing@example.com"));
        assertFalse(userService.existsByEmail("nonexisting@example.com"));
    }

    @Test
    void testMultipleUsersWithDifferentRoles() {
        // Arrange & Act
        User admin = userService.createUser("admin", "pass1", "admin@example.com", User.Role.ADMIN);
        User owner = userService.createUser("owner", "pass2", "owner@example.com", User.Role.DATA_OWNER);
        User user = userService.createUser("user", "pass3", "user@example.com", User.Role.AUTHORIZED_USER);

        // Assert
        assertEquals(User.Role.ADMIN, admin.getRole());
        assertEquals(User.Role.DATA_OWNER, owner.getRole());
        assertEquals(User.Role.AUTHORIZED_USER, user.getRole());

        var allUsers = userService.getAllUsers();
        assertEquals(3, allUsers.size());
    }
}

package com.edke.cloudsecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("test")
class CloudsecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}

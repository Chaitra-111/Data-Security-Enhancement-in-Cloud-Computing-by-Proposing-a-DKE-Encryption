package com.edke.cloudsecurity;

import com.edke.service.EncryptionService;
import com.edke.service.HashService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")
class EncryptionServiceTest {

    @Autowired
    private EncryptionService encryptionService;

    @Autowired
    private HashService hashService;

    @BeforeEach
    void setUp() {
        // Services are autowired by Spring
    }

    @Test
    void testEncryptFile() throws Exception {
        // Arrange
        byte[] testData = "Hello, Encryption!".getBytes();

        // Act
        Map<String, Object> result = encryptionService.encryptFile(testData);

        // Assert
        assertNotNull(result);
        assertNotNull(result.get("encryptedData"));
        assertNotNull(result.get("encryptedAESKey"));
        assertNotNull(result.get("originalHash"));
        assertNotNull(result.get("vmKey"));
        assertNotNull(result.get("serverKey"));

        // Encrypted data should differ from original
        assertNotEquals(new String(testData), new String((byte[]) result.get("encryptedData")));
    }

    @Test
    void testEncryptLargeFile() throws Exception {
        // Arrange
        byte[] largeData = new byte[1024 * 1024]; // 1MB
        for (int i = 0; i < largeData.length; i++) {
            largeData[i] = (byte) (i % 256);
        }

        // Act
        long startTime = System.currentTimeMillis();
        Map<String, Object> result = encryptionService.encryptFile(largeData);
        long encryptionTime = System.currentTimeMillis() - startTime;

        // Assert
        assertNotNull(result);
        assertTrue(encryptionTime < 5000, "Encryption should complete in less than 5 seconds");
        assertNotNull(result.get("encryptedData"));
    }

    @Test
    void testEncryptEmptyFile() throws Exception {
        // Arrange
        byte[] emptyData = new byte[0];

        // Act
        Map<String, Object> result = encryptionService.encryptFile(emptyData);

        // Assert
        assertNotNull(result);
        assertNotNull(result.get("encryptedData"));
    }

    @Test
    void testEncryptNullThrowsException() {
        // Act & Assert
        assertThrows(Exception.class, () -> encryptionService.encryptFile(null));
    }

    @Test
    void testDifferentEncryptionsProduceDifferentResults() throws Exception {
        // Arrange
        byte[] testData = "Same Data".getBytes();

        // Act
        Map<String, Object> result1 = encryptionService.encryptFile(testData);
        Map<String, Object> result2 = encryptionService.encryptFile(testData);

        // Assert - different session keys should produce different encrypted outputs
        assertNotEquals(
                new String((byte[]) result1.get("encryptedAESKey")),
                new String((byte[]) result2.get("encryptedAESKey"))
        );
        assertEquals(
                (String) result1.get("originalHash"),
                (String) result2.get("originalHash")
        );
    }
}

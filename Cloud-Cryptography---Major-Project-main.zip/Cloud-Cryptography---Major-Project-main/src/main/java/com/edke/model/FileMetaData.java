package com.edke.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "file_metadata")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class FileMetaData {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String fileName;

    @Column(nullable = false)
    private String fileType;

    @Column(nullable = false)
    private Long fileSize;

    @Column(nullable = false)
    private String hashValue;

    @Lob
    @Column(columnDefinition = "LONGBLOB")
    private byte[] encryptedData;

    @Lob
    @Column(columnDefinition = "LONGBLOB")
    private byte[] encryptedAESKey;

    @Lob
    @Column(columnDefinition = "LONGBLOB")
    private byte[] vmKey;

    @Lob
    @Column(columnDefinition = "LONGBLOB")
    private byte[] serverKey;

    @Column(nullable = false)
    private Long uploadedBy;

    @Column(nullable = false)
    private LocalDateTime uploadTimestamp;

    @Column(name = "is_accessible", nullable = false)
    private boolean accessible = true;

    @Column(nullable = false)
    private String encryptionAlgorithm = "AES-DKE";

    @Column(nullable = false)
    private Long encryptionTimeMs = 0L;

    @Column(nullable = false)
    private Long decryptionTimeMs = 0L;

    @Column(nullable = false)
    private String fileStatus = "UPLOADED";

    @Column
    private LocalDateTime lastAccessTime;

    @Column
    private Long downloadCount = 0L;

    @Column
    private Long accessAttempts = 0L;

    @Column
    private String storageLocation = "LOCAL";

    @Column
    private String storagePath;

    @Column
    private String integrityStatus = "VERIFIED";

    @Column
    private boolean requiresRoleAuth = true;

    @PrePersist
    protected void onCreate() {
        uploadTimestamp = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        lastAccessTime = LocalDateTime.now();
    }
}

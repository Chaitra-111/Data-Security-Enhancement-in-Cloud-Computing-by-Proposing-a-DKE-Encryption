package com.edke.util;

public class DKEUtil {

    public static byte[] encryptKey(byte[] aesKey, byte[] key1, byte[] key2) {
        byte[] temp = xor(aesKey, key1);
        return xor(temp, key2);
    }

    public static byte[] decryptKey(byte[] encryptedKey, byte[] key1, byte[] key2) {
        byte[] temp = xor(encryptedKey, key2);
        return xor(temp, key1);
    }

    private static byte[] xor(byte[] a, byte[] b) {
        byte[] result = new byte[a.length];
        for (int i = 0; i < a.length; i++)
            result[i] = (byte) (a[i] ^ b[i % b.length]);
        return result;
    }
}

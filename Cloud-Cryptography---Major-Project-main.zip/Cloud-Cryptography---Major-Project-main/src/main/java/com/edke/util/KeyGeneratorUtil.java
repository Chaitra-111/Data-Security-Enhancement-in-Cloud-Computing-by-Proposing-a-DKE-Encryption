package com.edke.util;

import java.security.MessageDigest;
import java.time.Instant;
import java.util.UUID;

public class KeyGeneratorUtil {

    public static byte[] generateSessionKey(String base) throws Exception {
        String input = base + Instant.now().toString() + UUID.randomUUID();
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        return md.digest(input.getBytes());
    }
}

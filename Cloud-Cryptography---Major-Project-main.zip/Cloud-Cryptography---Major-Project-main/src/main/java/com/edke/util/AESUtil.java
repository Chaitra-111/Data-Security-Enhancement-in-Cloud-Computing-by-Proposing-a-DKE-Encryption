package com.edke.util;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.SecureRandom;
import java.util.Arrays;

public class AESUtil {

    private static final String ALGORITHM = "AES/CBC/PKCS5Padding";
    private static final int IV_SIZE = 16;

    public static byte[] encrypt(byte[] data, byte[] key) throws Exception {
        SecretKeySpec skey = new SecretKeySpec(Arrays.copyOf(key, 16), "AES");
        byte[] iv = new byte[IV_SIZE];
        new SecureRandom().nextBytes(iv);
        IvParameterSpec ivSpec = new IvParameterSpec(iv);

        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.ENCRYPT_MODE, skey, ivSpec);
        byte[] encrypted = cipher.doFinal(data);

        // Prepend IV to encrypted data
        byte[] result = new byte[IV_SIZE + encrypted.length];
        System.arraycopy(iv, 0, result, 0, IV_SIZE);
        System.arraycopy(encrypted, 0, result, IV_SIZE, encrypted.length);
        return result;
    }

    public static byte[] decrypt(byte[] data, byte[] key) throws Exception {
        SecretKeySpec skey = new SecretKeySpec(Arrays.copyOf(key, 16), "AES");

        // Extract IV from the beginning of data
        byte[] iv = Arrays.copyOfRange(data, 0, IV_SIZE);
        byte[] encryptedData = Arrays.copyOfRange(data, IV_SIZE, data.length);

        IvParameterSpec ivSpec = new IvParameterSpec(iv);
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, skey, ivSpec);
        return cipher.doFinal(encryptedData);
    }
}

package com.edke.repository;

import com.edke.model.FileMetaData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FileRepository extends JpaRepository<FileMetaData, Long> {
    List<FileMetaData> findByUploadedBy(Long uploadedBy);
    List<FileMetaData> findByFileNameContaining(String fileName);
    List<FileMetaData> findByFileStatus(String fileStatus);
    List<FileMetaData> findByIntegrityStatus(String integrityStatus);
    int countByUploadedBy(Long uploadedBy);
}

package com.edke.service;

import com.edke.util.AESUtil;
import com.edke.util.DKEUtil;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class DecryptionService {

    private final HashService hashService;

    public DecryptionService(HashService hashService) {
        this.hashService = hashService;
    }

    /**
     * Decrypts file data using hybrid DKE + AES decryption
     */
    public Map<String, Object> decryptFile(byte[] encryptedData, byte[] encryptedAESKey,
                                           byte[] vmKey, byte[] serverKey, String originalHash) throws Exception {

        // Decrypt AES key using DKE
        byte[] aesKey = DKEUtil.decryptKey(encryptedAESKey, vmKey, serverKey);

        // Decrypt data using AES
        byte[] decryptedData = AESUtil.decrypt(encryptedData, aesKey);

        // Verify integrity using hash
        String decryptedHash = hashService.generateHash(decryptedData);
        boolean integrityVerified = originalHash.equals(decryptedHash);

        // Prepare result
        Map<String, Object> result = new HashMap<>();
        result.put("decryptedData", decryptedData);
        result.put("integrityVerified", integrityVerified);
        result.put("verifiedHash", decryptedHash);

        return result;
    }

    /**
     * Decrypts only the AES key using DKE
     */
    public byte[] decryptAESKey(byte[] encryptedAESKey, byte[] vmKey, byte[] serverKey) throws Exception {
        return DKEUtil.decryptKey(encryptedAESKey, vmKey, serverKey);
    }

    /**
     * Verifies data integrity by comparing hashes
     */
    public boolean verifyIntegrity(byte[] originalData, String storedHash) throws Exception {
        String computedHash = hashService.generateHash(originalData);
        return computedHash.equals(storedHash);
    }
}

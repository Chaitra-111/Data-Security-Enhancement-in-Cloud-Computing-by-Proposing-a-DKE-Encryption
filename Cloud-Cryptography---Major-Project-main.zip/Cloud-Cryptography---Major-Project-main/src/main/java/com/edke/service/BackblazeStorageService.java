package com.edke.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HexFormat;
import java.util.UUID;
import java.util.logging.Logger;

/**
 * Service to store encrypted files on Backblaze B2 cloud storage.
 * Uses Backblaze B2's S3-compatible API with AWS Signature Version 4.
 * No AWS account or SDK required — pure Java HttpClient.
 */
@Service
public class BackblazeStorageService {

    private static final Logger log = Logger.getLogger(BackblazeStorageService.class.getName());

    @Value("${backblaze.keyId}")
    private String keyId;

    @Value("${backblaze.applicationKey}")
    private String applicationKey;

    @Value("${backblaze.bucketName}")
    private String bucketName;

    @Value("${backblaze.endpoint}")
    private String endpoint;

    private final HttpClient httpClient = HttpClient.newHttpClient();

    /**
     * Uploads encrypted bytes to Backblaze B2 and returns the object key.
     */
    public String uploadEncryptedFile(byte[] encryptedData, String originalFileName) throws Exception {
        String extension = "";
        if (originalFileName != null && originalFileName.contains(".")) {
            extension = originalFileName.substring(originalFileName.lastIndexOf("."));
        }
        String objectKey = "encrypted/" + UUID.randomUUID() + ".enc" + extension;

        String region = extractRegion(endpoint); // e.g. us-east-005
        String host = endpoint.replace("https://", "");
        String url = endpoint + "/" + bucketName + "/" + objectKey;

        String dateTime = ZonedDateTime.now(ZoneOffset.UTC)
                .format(DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmss'Z'"));
        String date = dateTime.substring(0, 8);

        String contentSha256 = sha256Hex(encryptedData);
        String contentType = "application/octet-stream";

        // Canonical headers (must be sorted alphabetically)
        String canonicalHeaders =
                "content-type:" + contentType + "\n" +
                "host:" + host + "\n" +
                "x-amz-content-sha256:" + contentSha256 + "\n" +
                "x-amz-date:" + dateTime + "\n";

        String signedHeaders = "content-type;host;x-amz-content-sha256;x-amz-date";

        // Canonical request
        String canonicalRequest =
                "PUT\n" +
                "/" + bucketName + "/" + objectKey + "\n" +
                "\n" +
                canonicalHeaders + "\n" +
                signedHeaders + "\n" +
                contentSha256;

        // String to sign
        String credentialScope = date + "/" + region + "/s3/aws4_request";
        String stringToSign =
                "AWS4-HMAC-SHA256\n" +
                dateTime + "\n" +
                credentialScope + "\n" +
                sha256Hex(canonicalRequest.getBytes(StandardCharsets.UTF_8));

        // Signing key
        byte[] signingKey = getSigningKey(applicationKey, date, region, "s3");
        String signature = HexFormat.of().formatHex(hmacSha256(signingKey, stringToSign));

        // Authorization header
        String authorization =
                "AWS4-HMAC-SHA256 Credential=" + keyId + "/" + credentialScope +
                ", SignedHeaders=" + signedHeaders +
                ", Signature=" + signature;

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Content-Type", contentType)
                .header("x-amz-date", dateTime)
                .header("x-amz-content-sha256", contentSha256)
                .header("Authorization", authorization)
                .PUT(HttpRequest.BodyPublishers.ofByteArray(encryptedData))
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() == 200 || response.statusCode() == 201) {
            log.info("File uploaded to Backblaze B2: " + objectKey);
            return objectKey;
        } else {
            throw new RuntimeException("Backblaze B2 upload failed. Status: " + response.statusCode() + " Body: " + response.body());
        }
    }

    /**
     * Downloads encrypted bytes from Backblaze B2 by object key.
     */
    public byte[] downloadEncryptedFile(String objectKey) throws Exception {
        String region = extractRegion(endpoint);
        String host = endpoint.replace("https://", "");
        String url = endpoint + "/" + bucketName + "/" + objectKey;

        String dateTime = ZonedDateTime.now(ZoneOffset.UTC)
                .format(DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmss'Z'"));
        String date = dateTime.substring(0, 8);

        String contentSha256 = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"; // empty body hash

        String canonicalHeaders =
                "host:" + host + "\n" +
                "x-amz-content-sha256:" + contentSha256 + "\n" +
                "x-amz-date:" + dateTime + "\n";

        String signedHeaders = "host;x-amz-content-sha256;x-amz-date";

        String canonicalRequest =
                "GET\n" +
                "/" + bucketName + "/" + objectKey + "\n" +
                "\n" +
                canonicalHeaders + "\n" +
                signedHeaders + "\n" +
                contentSha256;

        String credentialScope = date + "/" + region + "/s3/aws4_request";
        String stringToSign =
                "AWS4-HMAC-SHA256\n" +
                dateTime + "\n" +
                credentialScope + "\n" +
                sha256Hex(canonicalRequest.getBytes(StandardCharsets.UTF_8));

        byte[] signingKey = getSigningKey(applicationKey, date, region, "s3");
        String signature = HexFormat.of().formatHex(hmacSha256(signingKey, stringToSign));

        String authorization =
                "AWS4-HMAC-SHA256 Credential=" + keyId + "/" + credentialScope +
                ", SignedHeaders=" + signedHeaders +
                ", Signature=" + signature;

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("x-amz-date", dateTime)
                .header("x-amz-content-sha256", contentSha256)
                .header("Authorization", authorization)
                .GET()
                .build();

        HttpResponse<byte[]> response = httpClient.send(request, HttpResponse.BodyHandlers.ofByteArray());

        if (response.statusCode() == 200) {
            log.info("File downloaded from Backblaze B2: " + objectKey);
            return response.body();
        } else {
            throw new RuntimeException("Backblaze B2 download failed. Status: " + response.statusCode());
        }
    }

    /**
     * Deletes a file from Backblaze B2 by object key.
     */
    public void deleteEncryptedFile(String objectKey) throws Exception {
        String region = extractRegion(endpoint);
        String host = endpoint.replace("https://", "");
        String url = endpoint + "/" + bucketName + "/" + objectKey;

        String dateTime = ZonedDateTime.now(ZoneOffset.UTC)
                .format(DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmss'Z'"));
        String date = dateTime.substring(0, 8);

        String contentSha256 = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";

        String canonicalHeaders =
                "host:" + host + "\n" +
                "x-amz-content-sha256:" + contentSha256 + "\n" +
                "x-amz-date:" + dateTime + "\n";

        String signedHeaders = "host;x-amz-content-sha256;x-amz-date";

        String canonicalRequest =
                "DELETE\n" +
                "/" + bucketName + "/" + objectKey + "\n" +
                "\n" +
                canonicalHeaders + "\n" +
                signedHeaders + "\n" +
                contentSha256;

        String credentialScope = date + "/" + region + "/s3/aws4_request";
        String stringToSign =
                "AWS4-HMAC-SHA256\n" +
                dateTime + "\n" +
                credentialScope + "\n" +
                sha256Hex(canonicalRequest.getBytes(StandardCharsets.UTF_8));

        byte[] signingKey = getSigningKey(applicationKey, date, region, "s3");
        String signature = HexFormat.of().formatHex(hmacSha256(signingKey, stringToSign));

        String authorization =
                "AWS4-HMAC-SHA256 Credential=" + keyId + "/" + credentialScope +
                ", SignedHeaders=" + signedHeaders +
                ", Signature=" + signature;

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("x-amz-date", dateTime)
                .header("x-amz-content-sha256", contentSha256)
                .header("Authorization", authorization)
                .DELETE()
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() == 204 || response.statusCode() == 200) {
            log.info("File deleted from Backblaze B2: " + objectKey);
        } else {
            log.warning("Backblaze B2 delete returned status: " + response.statusCode());
        }
    }

    // ─── AWS Signature V4 Helpers ────────────────────────────────────────────

    private String extractRegion(String endpoint) {
        // e.g. https://s3.us-east-005.backblazeb2.com → us-east-005
        String host = endpoint.replace("https://", "").replace("http://", "");
        String[] parts = host.split("\\.");
        if (parts.length >= 2) {
            return parts[1]; // us-east-005
        }
        return "us-east-005";
    }

    private String sha256Hex(byte[] data) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        return HexFormat.of().formatHex(digest.digest(data));
    }

    private String sha256Hex(String data) throws Exception {
        return sha256Hex(data.getBytes(StandardCharsets.UTF_8));
    }

    private byte[] hmacSha256(byte[] key, String data) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(key, "HmacSHA256"));
        return mac.doFinal(data.getBytes(StandardCharsets.UTF_8));
    }

    private byte[] getSigningKey(String secretKey, String date, String region, String service) throws Exception {
        byte[] kDate    = hmacSha256(("AWS4" + secretKey).getBytes(StandardCharsets.UTF_8), date);
        byte[] kRegion  = hmacSha256(kDate, region);
        byte[] kService = hmacSha256(kRegion, service);
        return hmacSha256(kService, "aws4_request");
    }
}

package com.edke.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.*;
import java.util.UUID;

/**
 * Service to store encrypted files on the local file system.
 * Files are saved to the configured storage path (C:/edke-uploads by default).
 * MySQL stores only the file path (storagePath), not the raw bytes.
 */
@Service
public class LocalStorageService {

    @Value("${storage.local.path:C:/edke-uploads}")
    private String storagePath;

    /**
     * Saves encrypted bytes to disk and returns the file path.
     * @param encryptedData The AES-encrypted file bytes
     * @param originalFileName The original file name (used for extension)
     * @return The absolute path where the encrypted file was saved
     */
    public String saveEncryptedFile(byte[] encryptedData, String originalFileName) throws IOException {
        // Create storage directory if it doesn't exist
        Path storageDir = Paths.get(storagePath);
        if (!Files.exists(storageDir)) {
            Files.createDirectories(storageDir);
        }

        // Generate a unique file name to avoid collisions
        String extension = "";
        if (originalFileName != null && originalFileName.contains(".")) {
            extension = originalFileName.substring(originalFileName.lastIndexOf("."));
        }
        String uniqueFileName = UUID.randomUUID().toString() + ".enc" + extension;
        Path filePath = storageDir.resolve(uniqueFileName);

        // Write encrypted bytes to disk
        Files.write(filePath, encryptedData, StandardOpenOption.CREATE, StandardOpenOption.WRITE);

        return filePath.toAbsolutePath().toString();
    }

    /**
     * Reads encrypted bytes from disk.
     * @param filePath The path returned by saveEncryptedFile
     * @return The encrypted file bytes
     */
    public byte[] readEncryptedFile(String filePath) throws IOException {
        Path path = Paths.get(filePath);
        if (!Files.exists(path)) {
            throw new IOException("Encrypted file not found at: " + filePath);
        }
        return Files.readAllBytes(path);
    }

    /**
     * Deletes an encrypted file from disk.
     * @param filePath The path of the file to delete
     */
    public void deleteEncryptedFile(String filePath) throws IOException {
        Path path = Paths.get(filePath);
        if (Files.exists(path)) {
            Files.delete(path);
        }
    }

    /**
     * Returns the configured storage directory path.
     */
    public String getStoragePath() {
        return storagePath;
    }
}

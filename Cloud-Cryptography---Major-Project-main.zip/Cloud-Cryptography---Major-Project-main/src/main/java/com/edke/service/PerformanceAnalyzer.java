package com.edke.service;

import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.Map;

@Service
public class PerformanceAnalyzer {

    /**
     * Analyzes encryption performance
     */
    public Map<String, Object> analyzeEncryptionPerformance(long encryptionStartTime, long encryptionEndTime, long fileSize) {
        long encryptionTime = encryptionEndTime - encryptionStartTime;
        double throughput = (fileSize / (1024.0 * 1024.0)) / (encryptionTime / 1000.0);

        Map<String, Object> metrics = new HashMap<>();
        metrics.put("encryptionTimeMs", encryptionTime);
        metrics.put("fileSizeBytes", fileSize);
        metrics.put("fileSizeMB", fileSize / (1024.0 * 1024.0));
        metrics.put("throughputMBps", throughput);
        metrics.put("algorithm", "AES-DKE");

        return metrics;
    }

    /**
     * Analyzes decryption performance
     */
    public Map<String, Object> analyzeDecryptionPerformance(long decryptionStartTime, long decryptionEndTime, long fileSize) {
        long decryptionTime = decryptionEndTime - decryptionStartTime;
        double throughput = (fileSize / (1024.0 * 1024.0)) / (decryptionTime / 1000.0);

        Map<String, Object> metrics = new HashMap<>();
        metrics.put("decryptionTimeMs", decryptionTime);
        metrics.put("fileSizeBytes", fileSize);
        metrics.put("fileSizeMB", fileSize / (1024.0 * 1024.0));
        metrics.put("throughputMBps", throughput);
        metrics.put("algorithm", "AES-DKE");

        return metrics;
    }

    /**
     * Compares performance with other encryption algorithms
     */
    public Map<String, Object> compareWithOtherAlgorithms(long aesDkeEncryptionTime,
                                                          long aesOnlyEncryptionTime,
                                                          long rsaEncryptionTime) {
        Map<String, Object> comparison = new HashMap<>();

        comparison.put("aesDkeTimeMs", aesDkeEncryptionTime);
        comparison.put("aesOnlyTimeMs", aesOnlyEncryptionTime);
        comparison.put("rsaTimeMs", rsaEncryptionTime);

        double aesVsAesDke = ((double) (aesOnlyEncryptionTime - aesDkeEncryptionTime) / aesDkeEncryptionTime) * 100;
        double rsaVsAesDke = ((double) (rsaEncryptionTime - aesDkeEncryptionTime) / aesDkeEncryptionTime) * 100;

        comparison.put("aesVsAesDkePercentage", aesVsAesDke);
        comparison.put("rsaVsAesDkePercentage", rsaVsAesDke);
        comparison.put("bestAlgorithm", aesDkeEncryptionTime < aesOnlyEncryptionTime ? "AES-DKE" : "AES");

        return comparison;
    }

    /**
     * Calculates QoS parameters
     */
    public Map<String, Object> calculateQoS(long encryptionTime, long decryptionTime, long fileSize, Long uploadedBy) {
        Map<String, Object> qos = new HashMap<>();

        long totalTime = encryptionTime + decryptionTime;
        double responseTime = totalTime / 1000.0;

        double estimatedCost = (fileSize / (1024.0 * 1024.0)) * (totalTime / 1000.0) * 0.001;

        double availability = 99.9;

        qos.put("responseTimeSeconds", responseTime);
        qos.put("estimatedCostUSD", estimatedCost);
        qos.put("availabilityPercentage", availability);
        qos.put("encryptionTimeMs", encryptionTime);
        qos.put("decryptionTimeMs", decryptionTime);
        qos.put("userId", uploadedBy);

        return qos;
    }

    /**
     * Generates a comprehensive performance report
     */
    public Map<String, Object> generatePerformanceReport(long encryptionTime, long decryptionTime,
                                                         long fileSize, String filePath, String algorithm) {
        Map<String, Object> report = new HashMap<>();

        report.put("filePath", filePath);
        report.put("fileSizeMB", fileSize / (1024.0 * 1024.0));
        report.put("encryptionTimeMs", encryptionTime);
        report.put("decryptionTimeMs", decryptionTime);
        report.put("totalTimeMs", encryptionTime + decryptionTime);
        report.put("algorithm", algorithm);

        double encryptionThroughput = (fileSize / (1024.0 * 1024.0)) / (encryptionTime / 1000.0);
        double decryptionThroughput = (fileSize / (1024.0 * 1024.0)) / (decryptionTime / 1000.0);

        report.put("encryptionThroughputMBps", encryptionThroughput);
        report.put("decryptionThroughputMBps", decryptionThroughput);
        report.put("avgThroughputMBps", (encryptionThroughput + decryptionThroughput) / 2.0);

        return report;
    }
}

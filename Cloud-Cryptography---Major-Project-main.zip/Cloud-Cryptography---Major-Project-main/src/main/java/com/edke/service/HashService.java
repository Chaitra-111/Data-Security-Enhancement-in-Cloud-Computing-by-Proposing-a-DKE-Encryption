package com.edke.service;

import org.springframework.stereotype.Service;

import java.security.MessageDigest;

@Service
public class HashService {

    public String generateHash(byte[] data) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hash = md.digest(data);
        StringBuilder sb = new StringBuilder();
        for (byte b : hash)
            sb.append(String.format("%02x", b));
        return sb.toString();
    }

    public boolean verifyHash(byte[] data, String expectedHash) throws Exception {
        String actualHash = generateHash(data);
        return actualHash.equals(expectedHash);
    }
}

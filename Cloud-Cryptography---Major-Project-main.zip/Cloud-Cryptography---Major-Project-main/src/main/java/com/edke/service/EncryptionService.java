package com.edke.service;

import com.edke.util.AESUtil;
import com.edke.util.DKEUtil;
import com.edke.util.KeyGeneratorUtil;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class EncryptionService {

    private final HashService hashService;

    public EncryptionService(HashService hashService) {
        this.hashService = hashService;
    }

    /**
     * Encrypts file data using hybrid DKE + AES encryption
     */
    public Map<String, Object> encryptFile(byte[] data) throws Exception {
        // Generate session keys
        byte[] aesKey = KeyGeneratorUtil.generateSessionKey("AES");
        byte[] key1 = KeyGeneratorUtil.generateSessionKey("VM");
        byte[] key2 = KeyGeneratorUtil.generateSessionKey("SERVER");

        // Encrypt data with AES
        byte[] encryptedData = AESUtil.encrypt(data, aesKey);

        // Encrypt AES key with DKE
        byte[] encryptedAESKey = DKEUtil.encryptKey(aesKey, key1, key2);

        // Generate hash for integrity verification
        String hash = hashService.generateHash(data);

        // Prepare result
        Map<String, Object> result = new HashMap<>();
        result.put("encryptedData", encryptedData);
        result.put("encryptedAESKey", encryptedAESKey);
        result.put("originalHash", hash);
        result.put("vmKey", key1);
        result.put("serverKey", key2);

        return result;
    }

    /**
     * Encrypts only the AES key using DKE
     */
    public byte[] encryptAESKey(byte[] aesKey) throws Exception {
        byte[] key1 = KeyGeneratorUtil.generateSessionKey("VM");
        byte[] key2 = KeyGeneratorUtil.generateSessionKey("SERVER");
        return DKEUtil.encryptKey(aesKey, key1, key2);
    }
}

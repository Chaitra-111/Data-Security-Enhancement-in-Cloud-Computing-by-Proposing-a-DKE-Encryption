package com.edke.controller;

import com.edke.model.FileMetaData;
import com.edke.model.User;
import com.edke.repository.FileRepository;
import com.edke.service.BackblazeStorageService;
import com.edke.service.DecryptionService;
import com.edke.service.EncryptionService;
import com.edke.service.HashService;
import com.edke.service.LocalStorageService;
import com.edke.service.PerformanceAnalyzer;
import com.edke.service.UserService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.*;

@RestController
@RequestMapping("/api/file")
public class FileController {

    private final FileRepository fileRepository;
    private final EncryptionService encryptionService;
    private final DecryptionService decryptionService;
    private final HashService hashService;
    private final PerformanceAnalyzer performanceAnalyzer;
    private final UserService userService;
    private final LocalStorageService localStorageService;
    private final BackblazeStorageService backblazeStorageService;

    @Value("${storage.mode:local}")
    private String storageMode;

    public FileController(FileRepository fileRepository, EncryptionService encryptionService,
                          DecryptionService decryptionService, HashService hashService,
                          PerformanceAnalyzer performanceAnalyzer, UserService userService,
                          LocalStorageService localStorageService,
                          BackblazeStorageService backblazeStorageService) {
        this.fileRepository = fileRepository;
        this.encryptionService = encryptionService;
        this.decryptionService = decryptionService;
        this.hashService = hashService;
        this.performanceAnalyzer = performanceAnalyzer;
        this.userService = userService;
        this.localStorageService = localStorageService;
        this.backblazeStorageService = backblazeStorageService;
    }

    /**
     * Upload and encrypt a file.
     * If storage.mode=backblaze → uploads encrypted bytes to Backblaze B2.
     * If storage.mode=local     → saves encrypted bytes to C:/edke-uploads.
     */
    @PostMapping("/upload")
    public ResponseEntity<?> uploadFile(@RequestParam("file") MultipartFile file) {
        try {
            Long uploadedBy = getCurrentUserId();
            byte[] fileData = file.getBytes();

            long encryptionStartTime = System.currentTimeMillis();
            Map<String, Object> encryptionResult = encryptionService.encryptFile(fileData);
            long encryptionEndTime = System.currentTimeMillis();
            long encryptionTime = encryptionEndTime - encryptionStartTime;

            byte[] encryptedData = (byte[]) encryptionResult.get("encryptedData");

            String savedPath;
            String location;

            if ("backblaze".equalsIgnoreCase(storageMode)) {
                // Upload to Backblaze B2 cloud
                savedPath = backblazeStorageService.uploadEncryptedFile(encryptedData, file.getOriginalFilename());
                location = "BACKBLAZE";
            } else {
                // Save to local disk
                savedPath = localStorageService.saveEncryptedFile(encryptedData, file.getOriginalFilename());
                location = "LOCAL";
            }

            FileMetaData fileMetaData = new FileMetaData();
            fileMetaData.setFileName(file.getOriginalFilename());
            fileMetaData.setFileType(file.getContentType());
            fileMetaData.setFileSize(file.getSize());
            fileMetaData.setHashValue((String) encryptionResult.get("originalHash"));
            fileMetaData.setEncryptedData(null);
            fileMetaData.setEncryptedAESKey((byte[]) encryptionResult.get("encryptedAESKey"));
            fileMetaData.setVmKey((byte[]) encryptionResult.get("vmKey"));
            fileMetaData.setServerKey((byte[]) encryptionResult.get("serverKey"));
            fileMetaData.setUploadedBy(uploadedBy);
            fileMetaData.setEncryptionTimeMs(encryptionTime);
            fileMetaData.setEncryptionAlgorithm("AES-DKE");
            fileMetaData.setFileStatus("UPLOADED");
            fileMetaData.setIntegrityStatus("VERIFIED");
            fileMetaData.setStorageLocation(location);
            fileMetaData.setStoragePath(savedPath);

            FileMetaData savedFile = fileRepository.save(fileMetaData);

            Map<String, Object> perfMetrics = performanceAnalyzer.analyzeEncryptionPerformance(
                    encryptionStartTime, encryptionEndTime, file.getSize());

            return ResponseEntity.ok(Map.of(
                    "message", "File uploaded and encrypted successfully",
                    "fileId", savedFile.getId(),
                    "fileName", savedFile.getFileName(),
                    "fileSize", savedFile.getFileSize(),
                    "encryptionTimeMs", encryptionTime,
                    "storagePath", savedPath,
                    "storageLocation", location,
                    "performanceMetrics", perfMetrics
            ));

        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * Download and decrypt a file.
     * Reads encrypted bytes from Backblaze B2 or local disk based on storageLocation.
     */
    @GetMapping("/download/{fileId}")
    public ResponseEntity<?> downloadFile(@PathVariable Long fileId) {
        try {
            Long userId = getCurrentUserId();
            User user = userService.findById(userId)
                    .orElseThrow(() -> new RuntimeException("User not found"));

            FileMetaData fileMetaData = fileRepository.findById(fileId)
                    .orElseThrow(() -> new RuntimeException("File not found"));

            if (fileMetaData.isRequiresRoleAuth()) {
                if (!user.getRole().equals(User.Role.ADMIN) &&
                        !user.getRole().equals(User.Role.DATA_OWNER) &&
                        !user.getId().equals(fileMetaData.getUploadedBy())) {
                    return ResponseEntity.status(403).body(Map.of("error", "Access denied"));
                }
            }

            // Fetch encrypted bytes from the correct storage
            byte[] encryptedData;
            String loc = fileMetaData.getStorageLocation();

            if ("BACKBLAZE".equalsIgnoreCase(loc) && fileMetaData.getStoragePath() != null) {
                encryptedData = backblazeStorageService.downloadEncryptedFile(fileMetaData.getStoragePath());
            } else if ("LOCAL".equalsIgnoreCase(loc) && fileMetaData.getStoragePath() != null) {
                encryptedData = localStorageService.readEncryptedFile(fileMetaData.getStoragePath());
            } else if (fileMetaData.getEncryptedData() != null) {
                // Legacy: old files stored directly in DB
                encryptedData = fileMetaData.getEncryptedData();
            } else {
                return ResponseEntity.badRequest().body(Map.of("error", "Encrypted file data not found"));
            }

            long decryptionStartTime = System.currentTimeMillis();
            Map<String, Object> decryptionResult = decryptionService.decryptFile(
                    encryptedData,
                    fileMetaData.getEncryptedAESKey(),
                    fileMetaData.getVmKey(),
                    fileMetaData.getServerKey(),
                    fileMetaData.getHashValue()
            );
            long decryptionEndTime = System.currentTimeMillis();
            long decryptionTime = decryptionEndTime - decryptionStartTime;

            boolean integrityVerified = (boolean) decryptionResult.get("integrityVerified");
            if (!integrityVerified) {
                fileMetaData.setIntegrityStatus("CORRUPTED");
                fileRepository.save(fileMetaData);
                return ResponseEntity.badRequest().body(Map.of("error", "File integrity check failed"));
            }

            byte[] decryptedData = (byte[]) decryptionResult.get("decryptedData");

            fileMetaData.setDecryptionTimeMs(decryptionTime);
            fileMetaData.setDownloadCount(fileMetaData.getDownloadCount() + 1);
            fileMetaData.setLastAccessTime(java.time.LocalDateTime.now());
            fileRepository.save(fileMetaData);

            performanceAnalyzer.analyzeDecryptionPerformance(
                    decryptionStartTime, decryptionEndTime, fileMetaData.getFileSize());

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION,
                            "attachment; filename=\"" + fileMetaData.getFileName() + "\"")
                    .header("X-Decryption-Time-Ms", String.valueOf(decryptionTime))
                    .header("X-Integrity-Status", fileMetaData.getIntegrityStatus())
                    .body(decryptedData);

        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * Get file metadata
     */
    @GetMapping("/metadata/{fileId}")
    public ResponseEntity<?> getFileMetadata(@PathVariable Long fileId) {
        try {
            FileMetaData fileMetaData = fileRepository.findById(fileId)
                    .orElseThrow(() -> new RuntimeException("File not found"));

            Map<String, Object> metadata = new HashMap<>();
            metadata.put("fileId", fileMetaData.getId());
            metadata.put("fileName", fileMetaData.getFileName());
            metadata.put("fileType", fileMetaData.getFileType());
            metadata.put("fileSize", fileMetaData.getFileSize());
            metadata.put("uploadedBy", fileMetaData.getUploadedBy());
            metadata.put("uploadTimestamp", fileMetaData.getUploadTimestamp());
            metadata.put("encryptionAlgorithm", fileMetaData.getEncryptionAlgorithm());
            metadata.put("encryptionTimeMs", fileMetaData.getEncryptionTimeMs());
            metadata.put("decryptionTimeMs", fileMetaData.getDecryptionTimeMs());
            metadata.put("fileStatus", fileMetaData.getFileStatus());
            metadata.put("integrityStatus", fileMetaData.getIntegrityStatus());
            metadata.put("downloadCount", fileMetaData.getDownloadCount());
            metadata.put("storageLocation", fileMetaData.getStorageLocation());
            metadata.put("storagePath", fileMetaData.getStoragePath());

            return ResponseEntity.ok(metadata);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * List all files uploaded by current user
     */
    @GetMapping("/list")
    public ResponseEntity<?> listUserFiles() {
        try {
            Long userId = getCurrentUserId();
            List<FileMetaData> files = fileRepository.findByUploadedBy(userId);

            List<Map<String, Object>> filesList = new ArrayList<>();
            for (FileMetaData file : files) {
                filesList.add(Map.of(
                        "fileId", file.getId(),
                        "fileName", file.getFileName(),
                        "fileSize", file.getFileSize(),
                        "uploadTimestamp", file.getUploadTimestamp(),
                        "fileStatus", file.getFileStatus(),
                        "downloadCount", file.getDownloadCount(),
                        "storageLocation", file.getStorageLocation() != null ? file.getStorageLocation() : "LOCAL"
                ));
            }

            return ResponseEntity.ok(Map.of(
                    "totalFiles", files.size(),
                    "files", filesList
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * Delete a file — removes from Backblaze B2 or local disk, marks as deleted in DB
     */
    @DeleteMapping("/{fileId}")
    public ResponseEntity<?> deleteFile(@PathVariable Long fileId) {
        try {
            Long userId = getCurrentUserId();
            FileMetaData fileMetaData = fileRepository.findById(fileId)
                    .orElseThrow(() -> new RuntimeException("File not found"));

            if (!fileMetaData.getUploadedBy().equals(userId)) {
                User user = userService.findById(userId)
                        .orElseThrow(() -> new RuntimeException("User not found"));
                if (!user.getRole().equals(User.Role.ADMIN)) {
                    return ResponseEntity.status(403).body(Map.of("error", "Access denied"));
                }
            }

            // Delete from storage
            if (fileMetaData.getStoragePath() != null && !fileMetaData.getStoragePath().isEmpty()) {
                try {
                    if ("BACKBLAZE".equalsIgnoreCase(fileMetaData.getStorageLocation())) {
                        backblazeStorageService.deleteEncryptedFile(fileMetaData.getStoragePath());
                    } else {
                        localStorageService.deleteEncryptedFile(fileMetaData.getStoragePath());
                    }
                } catch (Exception ignored) {}
            }

            fileMetaData.setFileStatus("DELETED");
            fileMetaData.setAccessible(false);
            fileMetaData.setStoragePath(null);
            fileRepository.save(fileMetaData);

            return ResponseEntity.ok(Map.of("message", "File deleted successfully"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * Get performance metrics for a file
     */
    @GetMapping("/performance/{fileId}")
    public ResponseEntity<?> getFilePerformance(@PathVariable Long fileId) {
        try {
            FileMetaData fileMetaData = fileRepository.findById(fileId)
                    .orElseThrow(() -> new RuntimeException("File not found"));

            Map<String, Object> perfReport = performanceAnalyzer.generatePerformanceReport(
                    fileMetaData.getEncryptionTimeMs(),
                    fileMetaData.getDecryptionTimeMs(),
                    fileMetaData.getFileSize(),
                    fileMetaData.getFileName(),
                    fileMetaData.getEncryptionAlgorithm()
            );

            return ResponseEntity.ok(perfReport);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * Get all files (admin only)
     */
    @GetMapping("/admin/all")
    public ResponseEntity<?> getAllFiles() {
        try {
            User user = getCurrentUser();
            if (!user.getRole().equals(User.Role.ADMIN)) {
                return ResponseEntity.status(403).body(Map.of("error", "Admin access required"));
            }
            List<FileMetaData> files = fileRepository.findAll();
            return ResponseEntity.ok(Map.of("totalFiles", files.size(), "files", files));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    private Long getCurrentUserId() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        return userService.findByUsername(username)
                .map(User::getId)
                .orElseThrow(() -> new RuntimeException("User not found"));
    }

    private User getCurrentUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        return userService.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));
    }
}

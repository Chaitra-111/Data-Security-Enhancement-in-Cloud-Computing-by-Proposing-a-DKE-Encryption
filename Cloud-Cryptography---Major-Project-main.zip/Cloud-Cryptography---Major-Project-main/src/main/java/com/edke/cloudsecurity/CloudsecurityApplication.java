package com.edke.cloudsecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = "com.edke")
@EnableJpaRepositories(basePackages = "com.edke.repository")
@EntityScan(basePackages = "com.edke.model")
public class CloudsecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(CloudsecurityApplication.class, args);
	}

}

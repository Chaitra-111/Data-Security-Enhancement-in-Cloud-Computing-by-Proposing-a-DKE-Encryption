// ===== STATE =====
const state = {
    token: localStorage.getItem('edke_token') || null,
    user: JSON.parse(localStorage.getItem('edke_user') || 'null'),
    selectedFile: null,
    files: []
};

const API = '';  // same origin

// ===== TOKEN VALIDATION (defined early so it can be used in INIT) =====
function isTokenExpired(token) {
    if (!token) return true;
    try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        return payload.exp * 1000 < Date.now();
    } catch {
        return true;
    }
}

// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => {
    // apply theme preference (default to dark if none)
    const savedTheme = localStorage.getItem('edke_theme');
    applyTheme(savedTheme === 'light' ? 'light' : 'dark');

    // Auto-logout if token is expired
    if (state.token && isTokenExpired(state.token)) {
        state.token = null;
        state.user = null;
        localStorage.removeItem('edke_token');
        localStorage.removeItem('edke_user');
    }
    if (state.token && state.user) {
        showDashboard();
    } else {
        showAuthPage();
    }
});

// ===== AUTH =====
function showAuthPage() {
    document.getElementById('auth-page').classList.add('active');
    document.getElementById('dashboard-page').classList.remove('active');
}

function showDashboard() {
    document.getElementById('auth-page').classList.remove('active');
    document.getElementById('dashboard-page').classList.add('active');
    document.getElementById('sidebar-username').textContent = state.user?.username || 'User';
    document.getElementById('sidebar-role').textContent = state.user?.role || '';
    document.getElementById('topbar-username').textContent = 'Welcome, ' + (state.user?.username || 'User');
    loadDashboard();
}

function switchAuthTab(tab) {
    document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.auth-form').forEach(f => f.classList.remove('active'));
    document.querySelector(`.auth-tab[onclick="switchAuthTab('${tab}')"]`).classList.add('active');
    document.getElementById(tab + '-form').classList.add('active');
}

async function handleLogin(e) {
    e.preventDefault();
    const username = document.getElementById('login-username').value.trim();
    const password = document.getElementById('login-password').value;
    const errEl = document.getElementById('login-error');
    errEl.classList.add('hidden');

    try {
        const res = await fetch(`${API}/api/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Login failed');

        state.token = data.token;
        state.user = { username: data.username, role: data.role, id: data.userId };
        localStorage.setItem('edke_token', state.token);
        localStorage.setItem('edke_user', JSON.stringify(state.user));
        showDashboard();
        showToast('Login successful! Welcome back.', 'success');
    } catch (err) {
        errEl.textContent = err.message;
        errEl.classList.remove('hidden');
    }
}

async function handleRegister(e) {
    e.preventDefault();
    const username = document.getElementById('reg-username').value.trim();
    const email = document.getElementById('reg-email').value.trim();
    const password = document.getElementById('reg-password').value;
    const errEl = document.getElementById('register-error');
    const sucEl = document.getElementById('register-success');
    errEl.classList.add('hidden');
    sucEl.classList.add('hidden');

    try {
        const res = await fetch(`${API}/api/auth/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, email, password })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Registration failed');

        sucEl.textContent = 'Registration successful! Please login.';
        sucEl.classList.remove('hidden');
        document.getElementById('register-form').reset();
        setTimeout(() => switchAuthTab('login'), 1500);
    } catch (err) {
        errEl.textContent = err.message;
        errEl.classList.remove('hidden');
    }
}

function handleLogout() {
    state.token = null;
    state.user = null;
    state.files = [];
    localStorage.removeItem('edke_token');
    localStorage.removeItem('edke_user');
    showAuthPage();
    showToast('Logged out successfully', 'success');
}

// ===== NAVIGATION =====
function showSection(name) {
    document.querySelectorAll('.content-section').forEach(s => s.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    document.getElementById('section-' + name).classList.add('active');
    document.querySelector(`.nav-item[onclick="showSection('${name}')"]`).classList.add('active');

    const titles = {
        dashboard: 'Dashboard',
        upload: 'Upload & Encrypt File',
        files: 'My Encrypted Files',
        performance: 'Performance Metrics',
        about: 'About E-DKE Protocol'
    };
    document.getElementById('page-title').textContent = titles[name] || name;

    if (name === 'files') loadFiles();
    if (name === 'performance') loadPerfFileList();
}

function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    if (sidebar.classList.contains('open')) {
        closeSidebar();
    } else {
        openSidebar();
    }
}

function closeSidebar() {
    const sidebar = document.querySelector('.sidebar');
    const mainContent = document.querySelector('.main-content');
    sidebar.classList.remove('open');
    sidebar.classList.add('closed');
    mainContent.classList.add('full-width');
    
    // Hide the backdrop when sidebar is closed
    const backdrop = document.querySelector('.sidebar-backdrop');
    if (backdrop) {
        backdrop.classList.add('hidden');
    }
}

function openSidebar() {
    const sidebar = document.querySelector('.sidebar');
    const mainContent = document.querySelector('.main-content');
    sidebar.classList.add('open');
    sidebar.classList.remove('closed');
    mainContent.classList.remove('full-width');
    
    // Show backdrop on mobile
    const backdrop = document.querySelector('.sidebar-backdrop');
    if (backdrop) {
        backdrop.classList.remove('hidden');
    }
}

// ===== THEME SWITCHING =====
function applyTheme(theme) {
    if (theme === 'light') {
        document.body.classList.add('light-mode');
    } else {
        document.body.classList.remove('light-mode');
    }
    localStorage.setItem('edke_theme', theme);
    updateThemeIcon();
}

function toggleTheme() {
    const current = document.body.classList.contains('light-mode') ? 'light' : 'dark';
    applyTheme(current === 'light' ? 'dark' : 'light');
}

function updateThemeIcon() {
    const btn = document.getElementById('theme-toggle');
    if (!btn) return;
    const icon = btn.querySelector('i');
    if (document.body.classList.contains('light-mode')) {
        icon.className = 'fas fa-moon';
    } else {
        icon.className = 'fas fa-sun';
    }
}

// ===== API HELPER =====
async function apiFetch(url, options = {}) {
    const headers = { 'Authorization': `Bearer ${state.token}`, ...options.headers };
    const res = await fetch(API + url, { ...options, headers });
    if (res.status === 401) {
        handleLogout();
        throw new Error('Session expired. Please login again.');
    }
    return res;
}

// ===== TOKEN VALIDATION =====
function isTokenExpired(token) {
    if (!token) return true;
    try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        return payload.exp * 1000 < Date.now();
    } catch {
        return true;
    }
}

// ===== DASHBOARD =====
async function loadDashboard() {
    try {
        const res = await apiFetch('/api/file/list');
        if (!res.ok) return;
        const data = await res.json();
        state.files = data.files || [];

        document.getElementById('stat-total-files').textContent = data.totalFiles || 0;

        const verified = state.files.filter(f => f.fileStatus !== 'DELETED').length;
        document.getElementById('stat-verified').textContent = verified;

        const downloads = state.files.reduce((sum, f) => sum + (f.downloadCount || 0), 0);
        document.getElementById('stat-downloads').textContent = downloads;

        renderRecentFiles(state.files.slice(0, 5));
    } catch (err) {
        console.error('Dashboard load error:', err);
    }
}

function renderRecentFiles(files) {
    const container = document.getElementById('recent-files-list');
    if (!files || files.length === 0) {
        container.innerHTML = `<div class="empty-state"><i class="fas fa-folder-open"></i><p>No files uploaded yet</p></div>`;
        return;
    }
    container.innerHTML = files.map(f => `
        <div class="file-list-item">
            <div class="file-list-icon">${getFileIcon(f.fileName)}</div>
            <div class="file-list-info">
                <div class="file-list-name">${escHtml(f.fileName)}</div>
                <div class="file-list-meta">${formatSize(f.fileSize)} · ${formatDate(f.uploadTimestamp)}</div>
            </div>
            <span class="badge ${f.fileStatus === 'DELETED' ? 'badge-danger' : 'badge-success'}">${f.fileStatus}</span>
        </div>
    `).join('');
}

// ===== FILE UPLOAD =====
function handleDragOver(e) {
    e.preventDefault();
    document.getElementById('drop-zone').classList.add('drag-over');
}
function handleDragLeave(e) {
    document.getElementById('drop-zone').classList.remove('drag-over');
}
function handleDrop(e) {
    e.preventDefault();
    document.getElementById('drop-zone').classList.remove('drag-over');
    const file = e.dataTransfer.files[0];
    if (file) setSelectedFile(file);
}
function handleFileSelect(e) {
    const file = e.target.files[0];
    if (file) setSelectedFile(file);
}
function setSelectedFile(file) {
    state.selectedFile = file;
    document.querySelector('.drop-zone-content').classList.add('hidden');
    const preview = document.getElementById('file-preview');
    preview.classList.remove('hidden');
    document.getElementById('preview-name').textContent = file.name;
    document.getElementById('preview-size').textContent = formatSize(file.size);
    document.getElementById('upload-btn').disabled = false;
    document.getElementById('upload-result').classList.add('hidden');
}
function clearFile(e) {
    e.stopPropagation();
    state.selectedFile = null;
    document.querySelector('.drop-zone-content').classList.remove('hidden');
    document.getElementById('file-preview').classList.add('hidden');
    document.getElementById('upload-btn').disabled = true;
    document.getElementById('file-input').value = '';
}

async function uploadFile() {
    if (!state.selectedFile) return;
    const progressEl = document.getElementById('upload-progress');
    const resultEl = document.getElementById('upload-result');
    const btn = document.getElementById('upload-btn');

    btn.disabled = true;
    progressEl.classList.remove('hidden');
    resultEl.classList.add('hidden');

    try {
        const formData = new FormData();
        formData.append('file', state.selectedFile);

        const res = await apiFetch('/api/file/upload', { method: 'POST', body: formData });
        const data = await res.json();

        progressEl.classList.add('hidden');

        if (!res.ok) throw new Error(data.error || 'Upload failed');

        resultEl.innerHTML = `
            <h4><i class="fas fa-check-circle"></i> File Encrypted & Uploaded Successfully!</h4>
            <div class="result-item"><span class="result-label">File ID</span><span class="result-value">#${data.fileId}</span></div>
            <div class="result-item"><span class="result-label">File Name</span><span class="result-value">${escHtml(data.fileName)}</span></div>
            <div class="result-item"><span class="result-label">File Size</span><span class="result-value">${formatSize(data.fileSize)}</span></div>
            <div class="result-item"><span class="result-label">Encryption Time</span><span class="result-value">${data.encryptionTimeMs} ms</span></div>
            <div class="result-item"><span class="result-label">Algorithm</span><span class="result-value">AES-256 + Dual Key Encryption</span></div>
            <div class="result-item"><span class="result-label">Integrity Hash</span><span class="result-value">SHA-256 ✓</span></div>
        `;
        resultEl.classList.remove('hidden');
        showToast('File encrypted and uploaded!', 'success');
        clearFile({ stopPropagation: () => {} });
        loadDashboard();
    } catch (err) {
        progressEl.classList.add('hidden');
        btn.disabled = false;
        showToast(err.message, 'error');
    }
}

// ===== FILES LIST =====
async function loadFiles() {
    const tbody = document.getElementById('files-tbody');
    const loading = document.getElementById('files-loading');
    loading.classList.remove('hidden');
    tbody.innerHTML = '';

    try {
        const res = await apiFetch('/api/file/list');
        const data = await res.json();
        loading.classList.add('hidden');
        state.files = data.files || [];

        if (state.files.length === 0) {
            tbody.innerHTML = `<tr><td colspan="7" class="empty-row"><i class="fas fa-folder-open"></i> No files found</td></tr>`;
            return;
        }

        tbody.innerHTML = state.files.map(f => `
            <tr>
                <td>
                    <div class="file-name-cell">
                        ${getFileIcon(f.fileName)}
                        <span class="file-name-text" title="${escHtml(f.fileName)}">${escHtml(f.fileName)}</span>
                    </div>
                </td>
                <td>${formatSize(f.fileSize)}</td>
                <td>${formatDate(f.uploadTimestamp)}</td>
                <td><span class="badge ${f.fileStatus === 'DELETED' ? 'badge-danger' : 'badge-success'}">${f.fileStatus}</span></td>
                <td><span class="badge badge-success"><i class="fas fa-check"></i> Verified</span></td>
                <td>${f.downloadCount || 0}</td>
                <td>
                    <div class="actions-cell">
                        ${f.fileStatus !== 'DELETED' ? `
                        <button class="btn btn-sm btn-success btn-icon" onclick="downloadFile(${f.fileId}, '${escHtml(f.fileName)}')" title="Download & Decrypt">
                            <i class="fas fa-download"></i>
                        </button>` : ''}
                        <button class="btn btn-sm btn-outline btn-icon" onclick="viewMetadata(${f.fileId})" title="View Details">
                            <i class="fas fa-info-circle"></i>
                        </button>
                        ${f.fileStatus !== 'DELETED' ? `
                        <button class="btn btn-sm btn-danger btn-icon" onclick="deleteFile(${f.fileId})" title="Delete">
                            <i class="fas fa-trash"></i>
                        </button>` : ''}
                    </div>
                </td>
            </tr>
        `).join('');
    } catch (err) {
        loading.classList.add('hidden');
        showToast(err.message, 'error');
    }
}

async function downloadFile(fileId, fileName) {
    showToast('Decrypting and downloading...', 'success');
    try {
        const res = await apiFetch(`/api/file/download/${fileId}`);
        if (!res.ok) {
            const data = await res.json();
            throw new Error(data.error || 'Download failed');
        }
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = fileName;
        a.click();
        URL.revokeObjectURL(url);
        showToast('File decrypted and downloaded!', 'success');
        loadFiles();
        loadDashboard();
    } catch (err) {
        showToast(err.message, 'error');
    }
}

async function viewMetadata(fileId) {
    try {
        const res = await apiFetch(`/api/file/metadata/${fileId}`);
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Failed to load metadata');

        document.getElementById('modal-body').innerHTML = `
            <div class="meta-row"><span class="meta-label">File ID</span><span class="meta-value">#${data.fileId}</span></div>
            <div class="meta-row"><span class="meta-label">File Name</span><span class="meta-value">${escHtml(data.fileName)}</span></div>
            <div class="meta-row"><span class="meta-label">File Type</span><span class="meta-value">${data.fileType || 'Unknown'}</span></div>
            <div class="meta-row"><span class="meta-label">File Size</span><span class="meta-value">${formatSize(data.fileSize)}</span></div>
            <div class="meta-row"><span class="meta-label">Upload Date</span><span class="meta-value">${formatDate(data.uploadTimestamp)}</span></div>
            <div class="meta-row"><span class="meta-label">Encryption Algorithm</span><span class="meta-value">${data.encryptionAlgorithm}</span></div>
            <div class="meta-row"><span class="meta-label">Encryption Time</span><span class="meta-value">${data.encryptionTimeMs} ms</span></div>
            <div class="meta-row"><span class="meta-label">Decryption Time</span><span class="meta-value">${data.decryptionTimeMs > 0 ? data.decryptionTimeMs + ' ms' : 'Not yet decrypted'}</span></div>
            <div class="meta-row"><span class="meta-label">File Status</span><span class="meta-value"><span class="badge ${data.fileStatus === 'DELETED' ? 'badge-danger' : 'badge-success'}">${data.fileStatus}</span></span></div>
            <div class="meta-row"><span class="meta-label">Integrity Status</span><span class="meta-value"><span class="badge badge-success">${data.integrityStatus || 'VERIFIED'}</span></span></div>
            <div class="meta-row"><span class="meta-label">Download Count</span><span class="meta-value">${data.downloadCount || 0}</span></div>
        `;
        document.getElementById('metadata-modal').classList.remove('hidden');
    } catch (err) {
        showToast(err.message, 'error');
    }
}

async function deleteFile(fileId) {
    if (!confirm('Are you sure you want to delete this file?')) return;
    try {
        const res = await apiFetch(`/api/file/${fileId}`, { method: 'DELETE' });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Delete failed');
        showToast('File deleted successfully', 'success');
        loadFiles();
        loadDashboard();
    } catch (err) {
        showToast(err.message, 'error');
    }
}

function closeModal() {
    document.getElementById('metadata-modal').classList.add('hidden');
}

// ===== PERFORMANCE =====
async function loadPerfFileList() {
    const select = document.getElementById('perf-file-select');
    select.innerHTML = '<option value="">-- Select a file --</option>';
    try {
        const res = await apiFetch('/api/file/list');
        const data = await res.json();
        (data.files || []).filter(f => f.fileStatus !== 'DELETED').forEach(f => {
            const opt = document.createElement('option');
            opt.value = f.fileId;
            opt.textContent = f.fileName;
            select.appendChild(opt);
        });
    } catch (err) {
        console.error(err);
    }
}

async function loadPerformance() {
    const fileId = document.getElementById('perf-file-select').value;
    const resultEl = document.getElementById('perf-result');
    if (!fileId) { resultEl.classList.add('hidden'); return; }

    try {
        const res = await apiFetch(`/api/file/performance/${fileId}`);
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Failed to load performance');

        document.getElementById('perf-enc-time').textContent = (data.encryptionTimeMs || 0) + ' ms';
        document.getElementById('perf-dec-time').textContent = (data.decryptionTimeMs || 0) > 0 ? data.decryptionTimeMs + ' ms' : 'N/A';
        document.getElementById('perf-file-size').textContent = formatSize(data.fileSize || 0);
        document.getElementById('perf-throughput').textContent = data.encryptionThroughputMBps
            ? data.encryptionThroughputMBps.toFixed(2) + ' MB/s'
            : (data.throughputMBps ? data.throughputMBps.toFixed(2) + ' MB/s' : 'N/A');

        const details = document.getElementById('perf-details');
        details.innerHTML = Object.entries(data).map(([k, v]) => {
            if (['encryptionTimeMs','decryptionTimeMs','fileSize'].includes(k)) return '';
            const label = k.replace(/([A-Z])/g, ' $1').replace(/^./, s => s.toUpperCase());
            const value = typeof v === 'number' ? (Number.isInteger(v) ? v : v.toFixed(4)) : v;
            return `<div class="perf-detail-row"><span class="perf-detail-label">${label}</span><span class="perf-detail-value">${value}</span></div>`;
        }).join('');

        resultEl.classList.remove('hidden');
    } catch (err) {
        showToast(err.message, 'error');
    }
}

// ===== UTILITIES =====
function formatSize(bytes) {
    if (!bytes) return '0 B';
    const units = ['B', 'KB', 'MB', 'GB'];
    let i = 0;
    while (bytes >= 1024 && i < units.length - 1) { bytes /= 1024; i++; }
    return bytes.toFixed(i > 0 ? 1 : 0) + ' ' + units[i];
}

function formatDate(dateStr) {
    if (!dateStr) return '--';
    try {
        return new Date(dateStr).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' });
    } catch { return dateStr; }
}

function escHtml(str) {
    if (!str) return '';
    return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function getFileIcon(name) {
    if (!name) return '<i class="fas fa-file"></i>';
    const ext = name.split('.').pop().toLowerCase();
    const icons = {
        pdf: 'fa-file-pdf', doc: 'fa-file-word', docx: 'fa-file-word',
        xls: 'fa-file-excel', xlsx: 'fa-file-excel',
        ppt: 'fa-file-powerpoint', pptx: 'fa-file-powerpoint',
        jpg: 'fa-file-image', jpeg: 'fa-file-image', png: 'fa-file-image', gif: 'fa-file-image',
        mp4: 'fa-file-video', avi: 'fa-file-video', mov: 'fa-file-video',
        mp3: 'fa-file-audio', wav: 'fa-file-audio',
        zip: 'fa-file-zipper', rar: 'fa-file-zipper', gz: 'fa-file-zipper',
        txt: 'fa-file-lines', csv: 'fa-file-csv',
        js: 'fa-file-code', java: 'fa-file-code', py: 'fa-file-code', html: 'fa-file-code'
    };
    return `<i class="fas ${icons[ext] || 'fa-file'}"></i>`;
}

function showToast(message, type = 'success') {
    const toast = document.getElementById('toast');
    const icon = type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle';
    toast.className = `toast ${type}`;
    toast.innerHTML = `<i class="fas ${icon}"></i> ${escHtml(message)}`;
    toast.classList.remove('hidden');
    clearTimeout(toast._timer);
    toast._timer = setTimeout(() => toast.classList.add('hidden'), 3500);
}
